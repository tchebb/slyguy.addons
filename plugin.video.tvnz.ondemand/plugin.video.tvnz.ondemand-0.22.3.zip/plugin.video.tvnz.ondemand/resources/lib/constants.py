HEADERS = {
    'User-Agent': 'Android/Ondemand/609',
    'x-tvnz-api-client-id': 'androidphone/2.64.3.609',
}

API_URL = 'https://apis-public-prod.tech.tvnz.co.nz{}'
IMG_BASE = 'https://api.tvnz.co.nz{}'
EPG_URL = 'https://i.mjh.nz/nz/tv.json.gz'
PAGE_LIMIT = 4
TOKEN_URL = 'https://i.mjh.nz/.tokens/tvnz.tk'


BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/{}'
BRIGHTCOVE_KEY = 'BCpkADawqM0IurzupiJKMb49WkxM__ngDMJ3GOQBhN2ri2Ci_lHwDWIpf4sLFc8bANMc-AVGfGR8GJNgxGqXsbjP1gHsK2Fpkoj6BSpwjrKBnv1D5l5iGPvVYCo'
BRIGHTCOVE_ACCOUNT = '963482467001'
