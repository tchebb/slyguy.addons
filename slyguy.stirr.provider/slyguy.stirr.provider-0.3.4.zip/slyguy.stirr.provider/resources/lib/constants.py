DATA_URL = 'https://i.mjh.nz/Stirr/.channels.json.gz'
ALL = 'all'
MY_CHANNELS = 'my_channels'
PLAYBACK_URL = 'https://jmp2.uk/str-{id}.m3u8'
