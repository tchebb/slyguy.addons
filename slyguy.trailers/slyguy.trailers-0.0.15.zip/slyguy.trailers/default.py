from resources.lib.plugin import plugin

plugin.dispatch()
